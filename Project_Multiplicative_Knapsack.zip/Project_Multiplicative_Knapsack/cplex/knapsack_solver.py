import math
import cplex
from cplex.exceptions import CplexError


class KnapsackProblem:
    def __init__(self, weights, capacity, values1, values2):
        self.weights = weights
        self.capacity = capacity
        self.values1 = values1
        self.values2 = values2
        self.n = len(weights)
        
    # def dp_solution(self, values, weights, capacity):
    #     n = len(values)
    #     dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    #     for i in range(1, n + 1):
    #         val = values[i - 1]
    #         wt = weights[i - 1]
    #         for w in range(capacity + 1):
    #             dp[i][w] = dp[i - 1][w]
    #             if wt <= w:
    #                 dp[i][w] = max(dp[i][w], dp[i - 1][w - wt] + val)
    #     max_value = dp[n][capacity]
    #     x = [0] * n
    #     w = capacity
    #     for i in range(n, 0, -1):
    #         if dp[i][w] != dp[i - 1][w]:
    #             x[i - 1] = 1
    #             w -= weights[i - 1]
    #     return max_value, x

    def solver_knapsack(self, values, weights, capacity):
        """        Parameters:
          values   : list of objective coefficients (e.g., either values1 or values2)
          weights  : list of weights for each item
          capacity : maximum capacity of the knapsack
        
        Returns:
          A tuple (total_value, x) where total_value is the maximum value obtained and
          x is a list of 0/1 decisions indicating whether each item is selected.
        """
        try:
            # Create a CPLEX problem instance.
            cpx = cplex.Cplex()
        except CplexError as e:
            print("Error creating CPLEX object:", e)
            return None

        # Create a CPLEX problem instance.
        # cpx = cplex.Cplex()

        # Set the problem to a maximization problem.
        cpx.objective.set_sense(cpx.objective.sense.minimize)

        # Create binary decision variables for each item.
        var_names = [f"x{i}" for i in range(self.n)]
        cpx.variables.add(
            obj=values,              # objective coefficients
            lb=[0.0] * self.n,       # lower bounds
            ub=[1.0] * self.n,       # upper bounds
            types=["B"] * self.n,    # binary variables
            names=var_names
        )

        # Add the capacity constraint: sum(weights[i] * x[i]) <= capacity.
        indices = list(range(self.n))
        knapsack_constraint = cplex.SparsePair(ind=indices, val=weights)
        cpx.linear_constraints.add(
            lin_expr=[knapsack_constraint],
            senses=["G"],            # "L" indicates less-than-or-equal-to
            rhs=[capacity],
            names=["capacity"]
        )

        # Solve the problem.
        # cpx.solve()
        try:
            # Solve the problem.
            cpx.solve()
        except CplexError as e:
            print("Error during solving:", e)
            # return None
        
            # Use CPLEX conflict refiner to find infeasible constraints
            cpx.conflict.refine(cpx.linear_constraints.get_indices())
            conflicts = cpx.conflict.get()
            
            print("\nInfeasible Constraints:")
            for conflict in conflicts:
                constraint_index = conflict[0]
                conflict_status = conflict[1]
                print(f"Constraint: {cpx.linear_constraints.get_names(constraint_index)}, Status: {conflict_status}")


        # Retrieve the solution values.
        solution_values = cpx.solution.get_values()

        # Convert the solution to binary decisions.
        x = [1.0 if val > 0.5 else 0.0 for val in solution_values]

        # Calculate the total objective value.
        # total_value = sum(x[i] * values[i] for i in range(self.n))
        total_value = sum(v * xi for v, xi in zip(values, x))

        return total_value, x

    @staticmethod
    def compute_total_value(values, x):
        return sum(v * xi for v, xi in zip(values, x))
    

    def shift_f(self):
        max_value_values1, _ = self.solver_knapsack(self.values1, self.weights, self.capacity)
        max_value_values2, _ = self.solver_knapsack(self.values2, self.weights, self.capacity)
        combined_values_1 = [v1 + v2 / (max_value_values2 ** 2)
                             for v1, v2 in zip(self.values1, self.values2)]
        _, x_1_star = self.solver_knapsack(combined_values_1, self.weights, self.capacity)
        cross_value_values2 = self.compute_total_value(self.values2, x_1_star)

        combined_values_2 = [v1 / (max_value_values1 ** 2) + v2
                             for v1, v2 in zip(self.values1, self.values2)]
        _, x_2_star = self.solver_knapsack(combined_values_2, self.weights, self.capacity)
        cross_value_values1 = self.compute_total_value(self.values1, x_2_star)
        return max_value_values1, cross_value_values2, x_1_star, max_value_values2, cross_value_values1, x_2_star

    def knapsack_alpha_solution(self, alpha):
        combined_values = [(1 - alpha) * v1 + alpha * v2
                           for v1, v2 in zip(self.values1, self.values2)]
        _, x = self.solver_knapsack(combined_values, self.weights, self.capacity)
        total_value_f1 = self.compute_total_value(self.values1, x)
        total_value_f2 = self.compute_total_value(self.values2, x)

        # max_value_values1, cross_value_values2, x_1_star, max_value_values2, cross_value_values1, x_2_star = self.shift_f()
        # P = total_value_f1 - cross_value_values1
        # Q = total_value_f2 - cross_value_values2
        P = total_value_f1 
        Q = total_value_f2

        return P, Q, x



# Example usage:
if __name__ == '__main__':
    import random
    random.seed(1)

    n_items = 100
    weights = [random.randint(1, 20) for _ in range(n_items)]
    total_weight = sum(weights)
    capacity = int(0.5 * total_weight)

    values1 = [random.randint(1, 50) for _ in range(n_items)]
    values2 = [random.randint(20, 40) for _ in range(n_items)]

    knap = KnapsackProblem(weights, capacity, values1, values2)
    epsilon = 1025
    epsilon2 = 600
    # print("f1:", knap.f1())
    # print("f2:", knap.f2())
    print("Alpha solution (alpha=0.5):", knap.knapsack_alpha_solution(0.5))