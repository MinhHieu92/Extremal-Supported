import random
import json

# Set seed for reproducibility
random.seed(30)

# Define item sizes from 20 to 500 with a step of 20
item_sizes = list(range(20, 501, 20))

# Function to generate instances with specified capacity ratio
def generate_instances(capacity_ratio):
    instances = []
    for n_items in item_sizes:
        # Generate random weights
        weights = [random.randint(1, 15) for _ in range(n_items)]

        # Compute capacity as per the ratio
        total_weight = sum(weights)
        capacity = int(capacity_ratio * total_weight)  # Ensure integer capacity

        # Generate two different sets of values
        values1 = [random.randint(1, 50) for _ in range(n_items)]
        values2 = [random.randint(20, 40) for _ in range(n_items)]

        instances.append({
            "n_items": n_items,
            "capacity": capacity,
            "weights": weights,
            "values1": values1,
            "values2": values2
        })
    return instances

# Generate and save instances for each capacity ratio
capacity_ratios = [0.5]
file_names = ["knapsack_instances_50.json"]

for ratio, file_name in zip(capacity_ratios, file_names):
    instances = generate_instances(ratio)
    with open(file_name, "w") as f:
        json.dump(instances, f, indent=4)
    print(f"Knapsack instances saved to {file_name}")
