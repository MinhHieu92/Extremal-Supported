import cplex
import random
import time

def calculate_bounds(weights, profits1, profits2, capacity):
    n = len(weights)

    # Calculate P_min and Q_min (minimizing individual objectives)
    P_min = min(profits1)
    Q_min = min(profits2)

    # Calculate P_max and Q_max (sum of all profits when all items are selected)
    P_max = sum(profits1)
    Q_max = sum(profits2)

    return P_min, P_max, Q_min, Q_max

def solve_bi_objective_knapsack_cplex(weights, profits1, profits2, capacity, lp_filename="knapsack_problem.lp"):
    n = len(weights)

    # Calculate bounds for P and Q
    P_min, P_max, Q_min, Q_max = calculate_bounds(weights, profits1, profits2, capacity)

    # Create the CPLEX model
    model = cplex.Cplex()
    model.set_problem_type(cplex.Cplex.problem_type.QP)
    model.objective.set_sense(model.objective.sense.minimize)

    # Variable names: x0, x1, ..., xn-1 (binary variables for item selection)
    var_names = [f"x{i}" for i in range(n)]

    # Add binary decision variables x_i
    model.variables.add(names=var_names, types=['B'] * n)

    # Add integer variables for P and Q (positive integers)
    model.variables.add(names=["P", "Q"], types=['I', 'I'], lb=[P_min, Q_min])

    # Knapsack constraint: Ensure total weight is at least the capacity
    knapsack_constraint = cplex.SparsePair(var_names, weights)
    model.linear_constraints.add(lin_expr=[knapsack_constraint], senses=["G"], rhs=[capacity])

    # Constraints to define P and Q:
    # P = sum(p1_i * x_i)
    P_constraint = cplex.SparsePair(var_names + ["P"], profits1 + [-1])
    model.linear_constraints.add(lin_expr=[P_constraint], senses=["E"], rhs=[0])

    # Q = sum(p2_i * x_i)
    Q_constraint = cplex.SparsePair(var_names + ["Q"], profits2 + [-1])
    model.linear_constraints.add(lin_expr=[Q_constraint], senses=["E"], rhs=[0])

    # Set quadratic objective: Minimize P * Q
    model.objective.set_quadratic_coefficients([("P", "Q", 1)])

    # Set optimality target to global optimality
    model.parameters.optimalitytarget.set(3)

    # Write the problem to a file
    model.write(lp_filename)

    # Solve the model
    model.solve()

    # Retrieve the solution
    solution_status = model.solution.get_status_string()
    if model.solution.is_primal_feasible():
        selected_items = [i for i in range(n) if model.solution.get_values(var_names[i]) > 0.5]
        P_value = model.solution.get_values("P")
        Q_value = model.solution.get_values("Q")
        Z_value = P_value * Q_value

        return {
            "status": solution_status,
            "selected_items": selected_items,
            "P": P_value,
            "Q": Q_value,
            "P*Q": Z_value
        }
    else:
        return {"status": solution_status, "message": "No feasible solution found."}

# Example usage:
if __name__ == "__main__":
    random.seed(1)

    n_items = 20 
    weights = [random.randint(1, 20) for _ in range(n_items)]
    total_weight = sum(weights)
    capacity = int(0.5 * total_weight)

    values1 = [random.randint(1, 50) for _ in range(n_items)]
    values2 = [random.randint(10, 40) for _ in range(n_items)]

    # Solve the problem
    start_time = time.time()
    result = solve_bi_objective_knapsack_cplex(weights, values1, values2, capacity)
    execution_time = time.time() - start_time

    # Display the results
    print("Status:", result["status"])
    print("Selected Items:", result.get("selected_items", []))
    print("Total P:", result.get("P"))
    print("Total Q:", result.get("Q"))
    print("Minimized P*Q:", result.get("P*Q"))
    print('execution_time:', execution_time)
