# run_ks_solution_50.py
import json
import time
from knapsack_solver import KnapsackProblem
from multiplicative_solver import BiObjectiveSolver
import matplotlib.pyplot as plt

# Load instances from file
instances_file = "knapsack_instances_50.json"
with open(instances_file, "r") as f:
    instances = json.load(f)

# Store results
results = []
TOLERANCE = 1e-10

for idx, instance in enumerate(instances):
    n_items = instance["n_items"]
    capacity = instance["capacity"]
    weights = instance["weights"]
    values1 = instance["values1"]
    values2 = instance["values2"]

    # Show progress
    print(f"[50% Capacity] Processing instance {idx + 1}/{len(instances)} with {n_items} items...")

    # Create KnapsackProblem instance
    knap = KnapsackProblem(weights, capacity, values1, values2)
    solver = BiObjectiveSolver(knap)

    # --- Multiplicative SOLUTION ---
    start_time = time.time()
    result_solution = solver.find_all_extreme_solutions()
    execution_time = time.time() - start_time

    # start_time = time.time()
    # result_min_product = solver.compare_product()
    # execution_time_2 = time.time() - start_time

    # total_execution_time = execution_time + execution_time_2
    # print(f"solution Processing instance {idx + 1}/{len(instances)}")

    # if isinstance(result_solution, tuple):
    #     result_cleaned = result_KS_solution[:-1]
    # else:
        # result_cleaned = result_KS_solution

    results.append({
        "n_items": n_items,
        "capacity": capacity,
        "execution_time": execution_time,
        # "total_execution_time": total_execution_time,
        "extreme_efficient_solutions": result_solution,
        # "solution_min_product": result_min_product
    })

    if n_items in [100, 180]:
        solutions = result_solution[0]  
        highlight_point = result_solution[1]  

        x_values = [point[0] for point in solutions]
        y_values = [point[1] for point in solutions]

        plt.figure(figsize=(8, 6))
        plt.scatter(x_values, y_values, color='black', label="Extreme Efficient Solutions", alpha=0.7)
        plt.scatter(*highlight_point, color='red', s=100, label="The solution of LMMP", edgecolors='black', linewidth=1.5)  

        plt.xlabel("Objective P")
        plt.ylabel("Objective Q")
        plt.title(f"Extreme Efficient Solutions for n = {n_items}")
        plt.legend()
        plt.grid(True)

        #Save figure
        plt.savefig(f"knapsack_plot_n{n_items}.png")
        print(f"Plot saved as knapsack_plot_n{n_items}.png")

# Save results
results_file = "knapsack_extreme_results_50.json"
with open(results_file, "w") as f:
    json.dump(results, f, indent=4)

print(f"[50% Capacity] KS solution results saved to {results_file}")
