import numpy as np
import matplotlib.pyplot as plt
from knapsack_solver import KnapsackProblem
import math
from typing import List, Tuple
import time


class BiObjectiveSolver:

    def __init__(self, problem):
        """
        Initialize the KS solver with a given combinatorial optimization problem.
        The problem instance must implement the following methods:
          - f1()
          - f2()
          - knapsack_alpha_solution(alpha)
          - knapsack_epsilon_constraint_cplex(epsilon, values1=None, values2=None)
        
        Parameters:
          - problem: an instance of a problem (e.g., KnapsackProblem)
        """
        self.problem = problem

    
    # def border_search(self, extreme_1, extreme_2):
    #     """
    #     Recursively finds extreme efficient solutions between two given solutions using the Geometric Method.
    #     :param extreme_1: First extreme solution (tuple of costs)
    #     :param extreme_2: Second extreme solution (tuple of costs)
    #     :return: List of new extreme solutions
    #     """
    #     (P1, Q1) = extreme_1
    #     (P2, Q2) = extreme_2

    #     # Compute new weights based on the linear combination formula
    #     # weighted_sum = [ o1 * (Q1 - Q2) + o2 * (P2 - P1) for o1, o2 in zip(self.problem.values1, self.problem.values2)]
    #     weighted_sum = (P2 - P1) / (Q1 - Q2 + P2 - P1)
    #     P_new, Q_new, x_new  = self.problem.knapsack_alpha_solution(weighted_sum)

    #     extreme_new = (P_new, Q_new)


    #     # Check if s_new lies on the line between s1 and s2
    #     if self.is_collinear(extreme_1, extreme_2, extreme_new):
    #         return []

    #     # Recursively find more extreme solutions
    #     left_solutions = self.border_search(extreme_1, extreme_new)
    #     right_solutions = self.border_search(extreme_new, extreme_2)

    #     return left_solutions + [extreme_new] + right_solutions

    def border_search(self, extreme_1, extreme_2, max_iterations=300):
        """
        Performs border search to find extreme efficient solutions and tracks the pair with the smallest product.

        :param extreme_1: First extreme solution (tuple of costs)
        :param extreme_2: Second extreme solution (tuple of costs)
        :param max_iterations: Maximum iterations to prevent infinite loops
        :return: Tuple containing (List of extreme solutions, Pair with smallest product)
        """
        stack = [(extreme_1, extreme_2)]
        new_extreme_solutions = []
        visited_solutions = set((extreme_1, extreme_2))  # Track already discovered points to avoid duplicates

        # Initialize the minimum product and corresponding pair
        min_product = extreme_1[0] * extreme_1[1]
        min_product_pair = extreme_1

        # Compare with the second extreme point
        if (extreme_2[0] * extreme_2[1]) < min_product:
            min_product = extreme_2[0] * extreme_2[1]
            min_product_pair = extreme_2

        iterations = 0

        while stack and iterations < max_iterations:
            iterations += 1
            current_extreme_1, current_extreme_2 = stack.pop()

            P1, Q1 = current_extreme_1
            P2, Q2 = current_extreme_2

            # Avoid division by zero
            denominator = (Q1 - Q2 + P2 - P1)
            if denominator == 0:
                continue

            weighted_sum = (P2 - P1) / denominator

            # Solve the problem with the new weighted sum
            P_new, Q_new, _ = self.problem.knapsack_alpha_solution(weighted_sum)
            extreme_new = (P_new, Q_new)

            # Round values to avoid floating-point precision errors when checking for duplicates
            extreme_new_rounded = (round(P_new, 6), round(Q_new, 6))

            # Check if the new point has already been found
            if extreme_new_rounded in visited_solutions:
                continue  # Skip if already discovered

            # Compare product immediately to track minimum product without scanning all solutions
            product_new = P_new * Q_new
            if product_new < min_product:
                min_product = product_new
                min_product_pair = extreme_new

            # Check for collinearity and add if not duplicate
            if not self.is_collinear(current_extreme_1, current_extreme_2, extreme_new):
                new_extreme_solutions.append(extreme_new)
                visited_solutions.add(extreme_new_rounded)  # Mark as discovered

                # Add to the stack to continue searching for new extreme points
                stack.append((current_extreme_1, extreme_new))
                stack.append((extreme_new, current_extreme_2))

        if iterations >= max_iterations:
            print("Reached maximum iterations, stopping to prevent infinite loop.")

        # Return the list of extreme solutions and the pair with the smallest product
        return sorted(new_extreme_solutions, key=lambda x: (x[0], x[1])), min_product_pair, iterations




    # def border_search(self, extreme_1, extreme_2, max_iterations=300):
    #     stack = [(extreme_1, extreme_2)]
    #     new_extreme_solutions = []
    #     visited_solutions = set((extreme_1, extreme_2))  # Track already discovered points to avoid duplicates
    #     iterations = 0

    #     while stack and iterations < max_iterations:
    #         iterations += 1
    #         current_extreme_1, current_extreme_2 = stack.pop()

    #         P1, Q1 = current_extreme_1
    #         P2, Q2 = current_extreme_2

    #         # Avoid division by zero
    #         denominator = (Q1 - Q2 + P2 - P1)
    #         if denominator == 0:
    #             continue

    #         weighted_sum = (P2 - P1) / denominator

    #         # Solve the problem with the new weighted sum
    #         P_new, Q_new, _ = self.problem.knapsack_alpha_solution(weighted_sum)
    #         extreme_new = (P_new, Q_new)

    #         # Round values to avoid floating-point precision errors when checking for duplicates
    #         extreme_new_rounded = (round(P_new, 6), round(Q_new, 6))

    #         # Check if the new point has already been found
    #         if extreme_new_rounded in visited_solutions:
    #             continue  # Skip if already discovered

    #         # Check for collinearity and add if not duplicate
    #         if not self.is_collinear(current_extreme_1, current_extreme_2, extreme_new):
    #             new_extreme_solutions.append(extreme_new)
    #             visited_solutions.add(extreme_new_rounded)  # Mark as discovered

    #             # Add to the stack to continue searching for new extreme points
    #             stack.append((current_extreme_1, extreme_new))
    #             stack.append((extreme_new, current_extreme_2))

    #     if iterations >= max_iterations:
    #         print("Reached maximum iterations, stopping to prevent infinite loop.")

    #     return sorted(new_extreme_solutions, key=lambda x: (x[0], x[1]))



    # def border_search(self, extreme_1, extreme_2):
    #     """
    #     Iteratively finds extreme efficient solutions between two given solutions using the Geometric Method.

    #     :param extreme_1: First extreme solution (tuple of costs)
    #     :param extreme_2: Second extreme solution (tuple of costs)
    #     :return: List of new extreme solutions
    #     """
    #     stack = [(extreme_1, extreme_2)]
    #     new_extreme_solutions = []

    #     while stack:
    #         current_extreme_1, current_extreme_2 = stack.pop()

    #         P1, Q1 = current_extreme_1
    #         P2, Q2 = current_extreme_2

    #         # Check if P1 == P2 and Q1 == Q2 to avoid division by zero
    #         if Q1 == Q2 and P1 == P2:
    #             # If both are equal, no new solution can be found between them
    #             continue

    #         # Compute new weighted sum based on the linear combination formula
    #         denominator = (Q1 - Q2 + P2 - P1)

    #         if denominator == 0:
    #             # If the denominator is zero, skip to avoid division by zero
    #             continue
            

    #         # Compute new weighted sum based on the linear combination formula
    #         weighted_sum = (P2 - P1) / denominator

    #         # Find new potential extreme solution
    #         P_new, Q_new, _ = self.problem.knapsack_alpha_solution(weighted_sum)
    #         extreme_new = (P_new, Q_new)

    #         # Check if the new solution lies on the line between current_extreme_1 and current_extreme_2
    #         if not self.is_collinear(current_extreme_1, current_extreme_2, extreme_new):
    #             # Add the new extreme solution to the list
    #             new_extreme_solutions.append(extreme_new)

    #             # Push the new sub-problems to the stack (simulate recursion)
    #             stack.append((current_extreme_1, extreme_new))
    #             stack.append((extreme_new, current_extreme_2))

    #     # Return the list of new extreme solutions in the correct order
    #     return sorted(new_extreme_solutions, key=lambda x: (x[0], x[1]))

    
    def is_collinear (self, extreme_1, extreme_2, extreme_new):

        tolerance = 1e-6

        (P1, Q1) = extreme_1
        (P2, Q2) = extreme_2
        (P_new, Q_new) = extreme_new 

        # if ( abs(P2 - P1) < tolerance and abs(Q2 - Q1) < tolerance ) :
        # # Both points are the same, can't define a line
        #     return False
        
        if ( abs(P2 - P_new) < tolerance and abs(Q2 - Q_new) < tolerance ) :
        # Both points are the same, can't define a line
            return False
        
        if ( abs(P_new - P1) < tolerance and abs(Q_new - Q1) < tolerance ) :
        # Both points are the same, can't define a line
            return False

        #check collinearity
        area = (Q_new - Q1) * (P2 - P1) - (Q2 - Q1) * (P_new - P1)
        
        if not math.isclose(area, 0, abs_tol=tolerance):
            return False

        #  check s_new lies on the straight line between s1 and s2
        on_segment_x = min(P1, P2) - tolerance <= P_new <= max(P1, P2) + tolerance
        on_segment_y = min(Q1, Q2) - tolerance <= Q_new <= max(Q1, Q2) + tolerance

        return on_segment_x and on_segment_y
    
    def find_all_extreme_solutions(self) -> List[Tuple[int, int]]:
        """
        Finds all extreme supported efficient solutions using the Geometric Method.
        :return: List of extreme efficient solutions
        """
        max_value_values1, cross_value_values2, x_1_star, max_value_values2, cross_value_values1, x_2_star = self.problem.shift_f()
        #(P_max, Q_min) and (P_min, Q_max)
        extreme_1 = (max_value_values1, cross_value_values2) 
        extreme_2 = (max_value_values2, cross_value_values1)
        
        if extreme_1 == extreme_2:
            return [extreme_1]
        
        list_extreme_solution, min_product_pair, iterations = self.border_search(extreme_1, extreme_2)
        
        # Find all intermediate extreme solutions
        self.extreme_solutions = [extreme_1] + list_extreme_solution + [extreme_2]
        return self.extreme_solutions, min_product_pair, iterations

    # def compare_product(self):
    #     """
    #     Compare the product of two integers in each pair from the list of solutions.

    #     :param solutions: List of pairs
    #     :param mode: 'min' to find the pair with the smallest product.
    #     :return: The pair [int, int] with the largest or smallest product.
    #     """
    #     solutions = self.find_all_extreme_solutions()

    #     # Check if solutions are empty
    #     if not solutions:
    #         return None
        
    #     return min(solutions, key=lambda pair: pair[0] * pair[1])



# Example usage:
if __name__ == "__main__":
    import random
    random.seed(1)

    n_items = 200 
    weights = [random.randint(1, 20) for _ in range(n_items)]
    total_weight = sum(weights)
    capacity = int(0.5 * total_weight)

    values1 = [random.randint(1, 50) for _ in range(n_items)]
    values2 = [random.randint(20, 40) for _ in range(n_items)]

    knap = KnapsackProblem(weights, capacity, values1, values2)
    solver = BiObjectiveSolver(knap)
    start_time = time.time()
    result_solution = solver.find_all_extreme_solutions()
    # result_min_product = solver.compare_product()
    execution_time = time.time() - start_time

    # print("search_phase_two_S_minus Result:", result_search_phase_two_S_minus)
    # print("search_phase_two_S_plus Result:", result_search_phase_two_S_plus)
    print("find_all_extreme_solutions:", result_solution)
    # print("compare_product:", result_min_product)
    print('execution_time:', execution_time)
